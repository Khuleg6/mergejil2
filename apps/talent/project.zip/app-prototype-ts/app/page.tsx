'use client';

import { useAppState } from '@/context/AppState';
import AuthGate from '@/components/AuthGate';
import TeacherShell from '@/components/TeacherShell';
import StudentShell from '@/components/StudentShell';

export default function Home() {
  const { session } = useAppState();

  if (session.role === 'TEACHER') return <TeacherShell />;
  if (session.role === 'STUDENT') return <StudentShell studentId={session.studentId} />;
  return <AuthGate />;
}
