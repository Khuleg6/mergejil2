import type { Metadata } from 'next';
import { AppStateProvider } from '@/context/AppState';
import './globals.css';

export const metadata: Metadata = {
  title: '[App name]',
  description: 'Reading & writing literacy platform for Deaf students',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <AppStateProvider>{children}</AppStateProvider>
      </body>
    </html>
  );
}
