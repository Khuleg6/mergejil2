'use client';

import { createContext, useContext, useCallback, useState, ReactNode } from 'react';
import type { Database, Student, AssignmentPhase } from '@/lib/types';
import { seedDatabase, AVATAR_CATALOG, PRACTICE_ITEMS } from '@/lib/seed';
import * as M from '@/lib/mutations';
import { findStudentByPhone } from '@/lib/selectors';

export type Session =
  | { role: null }
  | { role: 'TEACHER' }
  | { role: 'STUDENT'; studentId: string };

interface AppStateValue {
  db: Database;
  session: Session;
  loginTeacher: (email: string, password: string) => boolean;
  findStudentForLogin: (phone: string) => Student | null;
  verifyStudentOtp: (studentId: string) => void;
  logout: () => void;

  createClass: (name: string, teacherId: string) => void;
  addStudentToClass: (classId: string, name: string, phone: string) => void;
  uploadReadingMaterial: (classId: string, title: string, bodyText: string) => void;
  toggleVocabWord: (materialId: string, word: string) => void;
  createAssignment: (classId: string, materialId: string, wordIds: string[]) => void;
  unlockPhase: (assignmentId: string, phase: AssignmentPhase) => void;
  submitWordResponse: (
    assignmentId: string,
    studentId: string,
    wordId: string,
    phase: AssignmentPhase,
    text: string,
  ) => void;
  gradeWordResponse: (responseId: string, grade: 0 | 1 | 2, feedback?: string) => void;
  chooseAvatar: (studentId: string, avatarId: string) => void;
  submitExtraPracticeAttempt: (studentId: string, correct: boolean) => void;
}

const AppStateContext = createContext<AppStateValue | null>(null);

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [db, setDb] = useState<Database>(() => seedDatabase());
  const [session, setSession] = useState<Session>({ role: null });

  const loginTeacher = useCallback((email: string, password: string) => {
    if (!email.includes('@') || password.length < 1) return false;
    setSession({ role: 'TEACHER' });
    return true;
  }, []);

  const findStudentForLogin = useCallback(
    (phone: string) => findStudentByPhone(db, phone) ?? null,
    [db],
  );

  const verifyStudentOtp = useCallback((studentId: string) => {
    setSession({ role: 'STUDENT', studentId });
  }, []);

  const logout = useCallback(() => setSession({ role: null }), []);

  const createClass = useCallback((name: string, teacherId: string) => {
    setDb((prev) => M.createClass(prev, name, teacherId).db);
  }, []);
  const addStudentToClass = useCallback((classId: string, name: string, phone: string) => {
    setDb((prev) => M.addStudentToClass(prev, classId, name, phone).db);
  }, []);
  const uploadReadingMaterial = useCallback((classId: string, title: string, bodyText: string) => {
    setDb((prev) => M.uploadReadingMaterial(prev, classId, title, bodyText).db);
  }, []);
  const toggleVocabWord = useCallback((materialId: string, word: string) => {
    setDb((prev) => M.toggleVocabWord(prev, materialId, word));
  }, []);
  const createAssignment = useCallback((classId: string, materialId: string, wordIds: string[]) => {
    setDb((prev) => M.createAssignment(prev, classId, materialId, wordIds).db);
  }, []);
  const unlockPhase = useCallback((assignmentId: string, phase: AssignmentPhase) => {
    setDb((prev) => M.unlockPhase(prev, assignmentId, phase).db);
  }, []);
  const submitWordResponse = useCallback(
    (assignmentId: string, studentId: string, wordId: string, phase: AssignmentPhase, text: string) => {
      setDb((prev) => M.submitWordResponse(prev, assignmentId, studentId, wordId, phase, text).db);
    },
    [],
  );
  const gradeWordResponse = useCallback((responseId: string, grade: 0 | 1 | 2, feedback?: string) => {
    setDb((prev) => M.gradeWordResponse(prev, responseId, grade, feedback).db);
  }, []);
  const chooseAvatar = useCallback((studentId: string, avatarId: string) => {
    setDb((prev) => M.chooseAvatar(prev, studentId, avatarId).db);
  }, []);
  const submitExtraPracticeAttempt = useCallback((studentId: string, correct: boolean) => {
    setDb((prev) => M.submitExtraPracticeAttempt(prev, studentId, correct).db);
  }, []);

  const value: AppStateValue = {
    db, session,
    loginTeacher, findStudentForLogin, verifyStudentOtp, logout,
    createClass, addStudentToClass, uploadReadingMaterial, toggleVocabWord,
    createAssignment, unlockPhase, submitWordResponse, gradeWordResponse,
    chooseAvatar, submitExtraPracticeAttempt,
  };

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
}

export function useAppState(): AppStateValue {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error('useAppState must be used within AppStateProvider');
  return ctx;
}

export { AVATAR_CATALOG, PRACTICE_ITEMS };
