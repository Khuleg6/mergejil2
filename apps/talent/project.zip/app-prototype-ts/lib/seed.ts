import type { Database, Avatar, ExtraPracticeItem } from './types';
import { isoDaysAgo } from './selectors';

export function seedDatabase(): Database {
  return {
    classes: [{ id: 'c1', name: 'Room 12', teacherId: 't1' }],
    students: [
      { id: 's1', role: 'STUDENT', classId: 'c1', name: 'Maya P.', phone: '5550102231', level: 3, streakCount: 5, avatarId: 'a1', lastPracticeDate: isoDaysAgo(1) },
      { id: 's2', role: 'STUDENT', classId: 'c1', name: 'Jordan K.', phone: '5550109987', level: 2, streakCount: 1, avatarId: null, lastPracticeDate: null },
      { id: 's3', role: 'STUDENT', classId: 'c1', name: 'Ana R.', phone: '5550104410', level: 4, streakCount: 13, avatarId: 'a3', lastPracticeDate: isoDaysAgo(1) },
    ],
    materials: [
      {
        id: 'm1',
        classId: 'c1',
        title: 'Chapter 4: The Long Walk',
        bodyText:
          'The path stretched farther than Kira expected. Her legs felt weary after the third hill, but she was reluctant to stop while the light was still good. Somewhere past the horizon, she knew, the river was waiting.',
      },
    ],
    vocabWords: [
      { id: 'w1', materialId: 'm1', word: 'weary', position: 0 },
      { id: 'w2', materialId: 'm1', word: 'reluctant', position: 1 },
      { id: 'w3', materialId: 'm1', word: 'horizon', position: 2 },
    ],
    assignments: [
      {
        id: 'as1',
        classId: 'c1',
        materialId: 'm1',
        wordIds: ['w1', 'w2', 'w3'],
        phase1Unlocked: true,
        phase2Unlocked: false,
        phase3Unlocked: false,
        status: 'ACTIVE',
        dueAt: null,
      },
    ],
    responses: [
      {
        id: 'r1',
        assignmentId: 'as1',
        studentId: 's1',
        wordId: 'w1',
        phase: 'PREDICT',
        text: 'like when you want to stop moving',
        grade: null,
        feedback: '',
        submittedAt: new Date().toISOString(),
      },
    ],
  };
}

/** First four are free starters, available from onboarding on day one.
 *  The rest unlock purely from streakCount — see selectors.avatarUnlocked. */
export const AVATAR_CATALOG: Avatar[] = [
  { id: 'a1', name: 'Pebble', req: 0, color: '#997cf2' },
  { id: 'a2', name: 'Reed', req: 0, color: '#7a54ef' },
  { id: 'a3', name: 'Ember', req: 0, color: '#582ddc' },
  { id: 'a4', name: 'Bramble', req: 0, color: '#3c1e95' },
  { id: 'a5', name: 'Harbor', req: 7, color: '#717171' },
  { id: 'a6', name: 'Marsh', req: 14, color: '#555555' },
  { id: 'a7', name: 'Cinder', req: 30, color: '#eb664d' },
  { id: 'a8', name: 'Lumen', req: 60, color: '#de2300' },
];

export const PRACTICE_ITEMS: ExtraPracticeItem[] = [
  { id: 'p1', level: 1, word: 'cup', correct: 'cup', distractors: ['book', 'tree'] },
  { id: 'p2', level: 1, word: 'cat', correct: 'cat', distractors: ['shoe', 'book'] },
  { id: 'p3', level: 2, word: 'book', correct: 'book', distractors: ['cup', 'tree'] },
  { id: 'p4', level: 2, word: 'shoe', correct: 'shoe', distractors: ['cat', 'cup'] },
  { id: 'p5', level: 3, word: 'tree', correct: 'tree', distractors: ['cup', 'shoe'] },
];
