'use client';

import { useState } from 'react';
import { useAppState } from '@/context/AppState';
import SessionBar from './SessionBar';
import * as S from '@/lib/selectors';
import type { AssignmentPhase } from '@/lib/types';

type Tab = 'classes' | 'materials' | 'assignment' | 'grading' | 'reports';

export default function TeacherShell() {
  const { db } = useAppState();
  const [tab, setTab] = useState<Tab>('classes');
  const [selectedClassId, setSelectedClassId] = useState(db.classes[0]?.id ?? '');

  const currentClass = db.classes.find((c) => c.id === selectedClassId);

  const tabs: { key: Tab; label: string }[] = [
    { key: 'classes', label: 'Classes' },
    { key: 'materials', label: 'Materials' },
    { key: 'assignment', label: 'Assignment' },
    { key: 'grading', label: 'Grading' },
    { key: 'reports', label: 'Reports' },
  ];

  return (
    <>
      <SessionBar whoLabel={`Teacher · ${currentClass?.name ?? ''}`} />
      <div className="teacher-shell">
        <div className="sidebar">
          <div role="tablist" aria-label="Sections" aria-orientation="vertical">
            {tabs.map((t) => (
              <button
                key={t.key}
                role="tab"
                aria-selected={tab === t.key}
                onClick={() => setTab(t.key)}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
        <div className="teacher-main">
          {tab === 'classes' && (
            <ClassesPanel selectedClassId={selectedClassId} onSelectClass={setSelectedClassId} />
          )}
          {tab === 'materials' && (
            <MaterialsPanel classId={selectedClassId} onAssignmentCreated={() => setTab('assignment')} />
          )}
          {tab === 'assignment' && <AssignmentPanel classId={selectedClassId} onGoToMaterials={() => setTab('materials')} />}
          {tab === 'grading' && <GradingPanel classId={selectedClassId} />}
          {tab === 'reports' && <ReportsPanel classId={selectedClassId} />}
        </div>
      </div>
    </>
  );
}

function ClassesPanel({
  selectedClassId,
  onSelectClass,
}: {
  selectedClassId: string;
  onSelectClass: (id: string) => void;
}) {
  const { db, createClass, addStudentToClass } = useAppState();
  const [newClassName, setNewClassName] = useState('');
  const [newStudentName, setNewStudentName] = useState('');
  const [newStudentPhone, setNewStudentPhone] = useState('');

  const roster = S.rosterFor(db, selectedClassId);
  const currentClass = db.classes.find((c) => c.id === selectedClassId);

  return (
    <>
      <h1 className="page-title">Your classes</h1>
      <p className="page-sub">Pick a class to see the roster, or start a new one.</p>
      <div className="card">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {db.classes.map((c) => (
            <div
              key={c.id}
              onClick={() => onSelectClass(c.id)}
              style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '10px 12px', border: '1px solid var(--gray-100)', borderRadius: 6, cursor: 'pointer',
                borderColor: c.id === selectedClassId ? 'var(--highlight-background)' : undefined,
                background: c.id === selectedClassId ? 'var(--highlight-overlay)' : undefined,
              }}
            >
              <span style={{ fontWeight: 600, fontSize: 13.5 }}>{c.name}</span>
              <span style={{ fontSize: 12, color: 'var(--text-color-base)' }}>
                {S.rosterFor(db, c.id).length} students
              </span>
            </div>
          ))}
        </div>
        <div className="add-row">
          <input placeholder="New class name" value={newClassName} onChange={(e) => setNewClassName(e.target.value)} />
          <button
            className="btn outline"
            onClick={() => {
              if (!newClassName.trim()) return;
              createClass(newClassName.trim(), 't1');
              setNewClassName('');
            }}
          >
            Add class
          </button>
        </div>
      </div>
      <div className="card">
        <h2>{currentClass?.name ?? ''} — roster</h2>
        <p className="meta">Add a student by phone number. They&rsquo;ll use it to sign in.</p>
        <table>
          <thead>
            <tr><th>Name</th><th>Phone</th><th>Reading level</th><th>Streak</th></tr>
          </thead>
          <tbody>
            {roster.map((s) => (
              <tr key={s.id}>
                <td>{s.name}</td>
                <td>{S.formatPhone(s.phone)}</td>
                <td>Level {s.level}</td>
                <td>{s.streakCount} days</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="add-row">
          <input placeholder="Student name" value={newStudentName} onChange={(e) => setNewStudentName(e.target.value)} />
          <input placeholder="Phone number" value={newStudentPhone} onChange={(e) => setNewStudentPhone(e.target.value)} />
          <button
            className="btn"
            onClick={() => {
              const phone = S.normalizePhone(newStudentPhone);
              if (!newStudentName.trim() || phone.length < 7) return;
              addStudentToClass(selectedClassId, newStudentName.trim(), phone);
              setNewStudentName('');
              setNewStudentPhone('');
            }}
          >
            Add student
          </button>
        </div>
      </div>
    </>
  );
}

function MaterialsPanel({ classId, onAssignmentCreated }: { classId: string; onAssignmentCreated: () => void }) {
  const { db, uploadReadingMaterial, toggleVocabWord, createAssignment } = useAppState();
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');

  const material = S.materialFor(db, classId);

  if (!material) {
    return (
      <>
        <h1 className="page-title">Reading material</h1>
        <p className="page-sub">This class doesn&rsquo;t have a reading passage yet.</p>
        <div className="card">
          <label className="field-label">Title</label>
          <input placeholder="e.g. Chapter 1: Arrival" style={{ marginBottom: 12 }} value={title} onChange={(e) => setTitle(e.target.value)} />
          <label className="field-label">Passage text</label>
          <textarea placeholder="Paste or type the reading passage..." value={body} onChange={(e) => setBody(e.target.value)} />
          <button
            className="btn" style={{ marginTop: 14 }}
            onClick={() => {
              if (!title.trim() || !body.trim()) return;
              uploadReadingMaterial(classId, title.trim(), body.trim());
            }}
          >
            Save material
          </button>
        </div>
      </>
    );
  }

  const picked = S.vocabForMaterial(db, material.id).map((w) => w.word);
  const tokens = material.bodyText.split(/(\s+)/);

  return (
    <>
      <h1 className="page-title">Reading material</h1>
      <p className="page-sub">Select any word in the text to mark it as a vocabulary word.</p>
      <div className="card">
        <h2>{material.title}</h2>
        <div className="material-text">
          {tokens.map((tok, i) => {
            const clean = tok.replace(/[.,]/g, '').toLowerCase();
            if (/^[a-z]+$/.test(clean)) {
              return (
                <button
                  key={i}
                  type="button"
                  className="word"
                  aria-pressed={picked.includes(clean)}
                  onClick={() => toggleVocabWord(material.id, clean)}
                >
                  {tok}
                </button>
              );
            }
            return <span key={i}>{tok}</span>;
          })}
        </div>
        <p className="meta" style={{ marginTop: 14 }}>Selected words</p>
        <div className="picked-list">
          {picked.length === 0 ? (
            <span className="help-text">No words selected yet.</span>
          ) : (
            picked.map((w) => <span key={w} className="pill">{w}</span>)
          )}
        </div>
        <div style={{ marginTop: 16 }}>
          <button
            className="btn"
            onClick={() => {
              const words = S.vocabForMaterial(db, material.id);
              if (words.length === 0) return;
              createAssignment(classId, material.id, words.map((w) => w.id));
              onAssignmentCreated();
            }}
          >
            Create/update assignment with these words
          </button>
        </div>
      </div>
    </>
  );
}

const PHASE_INFO: { phase: AssignmentPhase; label: string; sub: string }[] = [
  { phase: 'PREDICT', label: 'Your guess', sub: "Turn on once you've signed the words in class" },
  { phase: 'CONFIRM', label: 'The real meaning', sub: 'Turn on after you teach the correct definitions' },
  { phase: 'APPLY', label: 'Use it in a sentence', sub: 'Turn on once meanings are confirmed' },
];

function AssignmentPanel({ classId, onGoToMaterials }: { classId: string; onGoToMaterials: () => void }) {
  const { db, unlockPhase } = useAppState();
  const assignment = S.assignmentFor(db, classId);
  const roster = S.rosterFor(db, classId);

  if (!assignment) {
    return (
      <>
        <h1 className="page-title">Assignment</h1>
        <p className="page-sub">No active assignment yet. Select vocabulary words in Materials first.</p>
        <div className="card"><button className="btn outline" onClick={onGoToMaterials}>Go to Materials</button></div>
      </>
    );
  }

  const material = db.materials.find((m) => m.id === assignment.materialId);
  const words = assignment.wordIds.map((id) => S.wordById(db, id)).filter((w) => !!w);
  const unlockedFlags: Record<AssignmentPhase, boolean> = {
    PREDICT: assignment.phase1Unlocked,
    CONFIRM: assignment.phase2Unlocked,
    APPLY: assignment.phase3Unlocked,
  };

  return (
    <>
      <h1 className="page-title">Assignment: {material?.title}</h1>
      <p className="page-sub">Words: {words.map((w) => w!.word).join(', ')}. Turn on each step when your class is ready.</p>
      <div className="card">
        <h2>Steps</h2>
        {PHASE_INFO.map((p) => (
          <div key={p.phase} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '11px 0', borderBottom: '1px solid var(--gray-100)' }}>
            <div>
              <div style={{ fontWeight: 600, fontSize: 13.5 }}>{p.label}</div>
              <div style={{ fontSize: 12, color: 'var(--text-color-base)' }}>{p.sub}</div>
            </div>
            <button role="switch" aria-checked={unlockedFlags[p.phase]} onClick={() => unlockPhase(assignment.id, p.phase)}>
              <span className="knob" />
            </button>
          </div>
        ))}
      </div>
      <div className="card">
        <h2>Submission status</h2>
        <table>
          <thead><tr><th>Student</th><th>Your guess</th><th>Real meaning</th><th>Sentence</th></tr></thead>
          <tbody>
            {roster.map((s) => (
              <tr key={s.id}>
                <td>{s.name}</td>
                {PHASE_INFO.map((p) => {
                  const status = S.phaseStatus(db, assignment, s.id, p.phase, unlockedFlags[p.phase]);
                  const label =
                    status.kind === 'locked' ? 'Locked'
                    : status.kind === 'submitted' ? 'Submitted'
                    : status.kind === 'in_progress' ? `${status.done}/${status.total}`
                    : 'Not yet';
                  const cls = status.kind === 'submitted' ? 'done' : status.kind === 'locked' ? 'locked' : 'open';
                  return <td key={p.phase}><span className={`badge ${cls}`}>{label}</span></td>;
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

function GradingPanel({ classId }: { classId: string }) {
  const { db, gradeWordResponse } = useAppState();
  const roster = S.rosterFor(db, classId);
  const [studentId, setStudentId] = useState(roster[0]?.id ?? '');
  const assignment = S.assignmentFor(db, classId);
  const [feedbackDraft, setFeedbackDraft] = useState<Record<string, string>>({});

  return (
    <>
      <h1 className="page-title">Grading</h1>
      <p className="page-sub">Compare each student&rsquo;s first guess with their confirmed meaning.</p>
      <div style={{ display: 'grid', gridTemplateColumns: '190px 1fr', gap: 16 }}>
        <div className="card">
          <div role="listbox" className="student-picker" aria-label="Students">
            {roster.map((s) => (
              <div
                key={s.id} role="option" className="student-option"
                aria-selected={s.id === studentId} onClick={() => setStudentId(s.id)}
              >
                {s.name}
              </div>
            ))}
          </div>
        </div>
        <div className="card">
          {!assignment ? (
            <p className="meta">No active assignment for this class yet.</p>
          ) : (
            assignment.wordIds.map((wordId) => {
              const word = S.wordById(db, wordId);
              if (!word) return null;
              const predict = S.getResponse(db, studentId, wordId, 'PREDICT');
              const confirm = S.getResponse(db, studentId, wordId, 'CONFIRM');
              const apply = S.getResponse(db, studentId, wordId, 'APPLY');
              const feedbackKey = confirm?.id ?? '';
              return (
                <div key={wordId} className="word-block">
                  <h3>{word.word}</h3>
                  <div className="grid2">
                    <div className="submitted-text">
                      <div className="help-text" style={{ margin: '0 0 3px' }}>Your guess</div>
                      {predict ? predict.text : <span className="locked-note">Not submitted yet</span>}
                    </div>
                    <div className="submitted-text">
                      <div className="help-text" style={{ margin: '0 0 3px' }}>Real meaning</div>
                      {confirm ? confirm.text : <span className="locked-note">Not submitted yet</span>}
                    </div>
                  </div>
                  {confirm && (
                    <>
                      <label className="field-label">Grade the real meaning</label>
                      <div role="radiogroup" className="grade-group">
                        {[0, 1, 2].map((n) => (
                          <div
                            key={n} role="radio" aria-checked={confirm.grade === n}
                            onClick={() => gradeWordResponse(confirm.id, n as 0 | 1 | 2)}
                          >
                            {n}
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                  <div className="submitted-text" style={{ margin: '10px 0 12px' }}>
                    <div className="help-text" style={{ margin: '0 0 3px' }}>Sentence</div>
                    {apply ? apply.text : <span className="locked-note">Not submitted yet</span>}
                  </div>
                  {apply && (
                    <>
                      <label className="field-label">Grade the sentence</label>
                      <div role="radiogroup" className="grade-group">
                        {[0, 1, 2].map((n) => (
                          <div
                            key={n} role="radio" aria-checked={apply.grade === n}
                            onClick={() => gradeWordResponse(apply.id, n as 0 | 1 | 2)}
                          >
                            {n}
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                  {confirm && (
                    <>
                      <label className="field-label" style={{ marginTop: 10 }}>Feedback</label>
                      <textarea
                        placeholder="Write a short note for the student"
                        value={feedbackDraft[feedbackKey] ?? confirm.feedback}
                        onChange={(e) => setFeedbackDraft((prev) => ({ ...prev, [feedbackKey]: e.target.value }))}
                        onBlur={(e) => gradeWordResponse(confirm.id, (confirm.grade ?? 0) as 0 | 1 | 2, e.target.value)}
                      />
                    </>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </>
  );
}

function ReportsPanel({ classId }: { classId: string }) {
  const { db } = useAppState();
  const assignment = S.assignmentFor(db, classId);
  const roster = S.rosterFor(db, classId);
  const currentClass = db.classes.find((c) => c.id === classId);
  const material = assignment ? db.materials.find((m) => m.id === assignment.materialId) : null;

  return (
    <>
      <h1 className="page-title">Class reports</h1>
      <p className="page-sub">{currentClass?.name}{material ? ` — ${material.title}` : ''}</p>
      <div className="card">
        <h2>Words students needed more support with</h2>
        <p className="meta">Share of graded &ldquo;real meaning&rdquo; answers scored 0–1 (out of 2)</p>
        {!assignment ? (
          <p className="meta">No active assignment yet.</p>
        ) : (
          assignment.wordIds.map((wordId) => {
            const word = S.wordById(db, wordId);
            if (!word) return null;
            const pct = S.wordSupportNeededPct(db, assignment, roster, wordId);
            return (
              <div key={wordId} className="bar-row">
                <div className="label">{word.word}</div>
                {pct === null ? (
                  <span className="help-text">Not graded yet</span>
                ) : (
                  <>
                    <div className="bar-track"><div className="bar-fill" style={{ width: `${pct}%` }} /></div>
                    <div className="val">{pct}%</div>
                  </>
                )}
              </div>
            );
          })
        )}
      </div>
      <div className="card">
        <h2>Student engagement</h2>
        <p className="meta">Current streaks across the class</p>
        {roster.map((s) => (
          <div key={s.id} className="bar-row">
            <div className="label">{s.name}</div>
            <div className="bar-track"><div className="bar-fill" style={{ width: `${Math.min(100, s.streakCount * 6)}%` }} /></div>
            <div className="val">{s.streakCount}d</div>
          </div>
        ))}
      </div>
    </>
  );
}
