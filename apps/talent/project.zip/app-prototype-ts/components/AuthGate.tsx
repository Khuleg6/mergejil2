'use client';

import { useState } from 'react';
import { useAppState } from '@/context/AppState';
import type { Student } from '@/lib/types';

type Step = 'chooser' | 'teacherLogin' | 'studentPhone' | 'studentOtp';

export default function AuthGate() {
  const { loginTeacher, findStudentForLogin, verifyStudentOtp } = useAppState();
  const [step, setStep] = useState<Step>('chooser');
  const [pendingStudent, setPendingStudent] = useState<Student | null>(null);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [teacherErr, setTeacherErr] = useState(false);

  const [phone, setPhone] = useState('');
  const [phoneErr, setPhoneErr] = useState(false);

  const [otp, setOtp] = useState(['', '', '', '']);
  const [otpErr, setOtpErr] = useState(false);

  function submitTeacherLogin() {
    if (loginTeacher(email, password)) return;
    setTeacherErr(true);
  }

  function submitPhone() {
    const student = findStudentForLogin(phone);
    if (!student) {
      setPhoneErr(true);
      return;
    }
    setPhoneErr(false);
    setPendingStudent(student);
    setStep('studentOtp');
  }

  function submitOtp() {
    if (otp.join('').length < 4) {
      setOtpErr(true);
      return;
    }
    verifyStudentOtp(pendingStudent!.id);
  }

  return (
    <div className="center-wrap">
      {step === 'chooser' && (
        <>
          <div className="wordmark">[App name]</div>
          <h1 className="title">Welcome</h1>
          <p className="sub-text">
            Sign in as either role to try the full loop — teacher actions here show up for
            students, and back.
          </p>
          <div className="role-choice">
            <button onClick={() => setStep('teacherLogin')}>I&rsquo;m a teacher</button>
            <button onClick={() => setStep('studentPhone')}>I&rsquo;m a student</button>
          </div>
        </>
      )}

      {step === 'teacherLogin' && (
        <>
          <div className="wordmark">
            [App name]
            <span className="sub">Teacher</span>
          </div>
          <div className="stepper">
            <div className="seg current" />
            <div className="seg" />
          </div>
          <h1 className="title">Sign in</h1>
          <p className="sub-text">Use your school email and password.</p>
          <div className="card">
            <label className="field-label" htmlFor="tEmail">Email</label>
            <input
              id="tEmail" type="email" placeholder="you@school.edu" style={{ marginBottom: 14 }}
              value={email} onChange={(e) => setEmail(e.target.value)}
            />
            <label className="field-label" htmlFor="tPass">Password</label>
            <input
              id="tPass" type="password" style={{ marginBottom: 6 }}
              value={password} onChange={(e) => setPassword(e.target.value)}
            />
            {teacherErr && <p className="error-text">Enter your email and password.</p>}
            <button className="btn block" style={{ marginTop: 14 }} onClick={submitTeacherLogin}>
              Sign in
            </button>
          </div>
          <button
            className="linkbtn" style={{ display: 'block', marginTop: 14, textAlign: 'center', width: '100%' }}
            onClick={() => setStep('chooser')}
          >
            Back
          </button>
        </>
      )}

      {step === 'studentPhone' && (
        <>
          <div className="wordmark">[App name]</div>
          <div className="stepper">
            <div className="seg current" />
            <div className="seg" />
            <div className="seg" />
          </div>
          <h1 className="title">Sign in</h1>
          <p className="sub-text">Enter your phone number. We&rsquo;ll text you a code.</p>
          <div className="card">
            <label className="field-label" htmlFor="sPhone">Phone number</label>
            <input
              id="sPhone" type="tel" placeholder="(555) 010-2231"
              value={phone} onChange={(e) => setPhone(e.target.value)}
            />
            {phoneErr && (
              <p className="error-text">
                We couldn&rsquo;t find that number. Ask your teacher to add you, or try a demo student.
              </p>
            )}
            <button className="btn block" style={{ marginTop: 14 }} onClick={submitPhone}>
              Send code
            </button>
            <button
              className="linkbtn" style={{ display: 'block', marginTop: 12 }}
              onClick={() => setPhone('(555) 010-2231')}
            >
              Fill in a demo student&rsquo;s number
            </button>
          </div>
          <button
            className="linkbtn" style={{ display: 'block', marginTop: 14, textAlign: 'center', width: '100%' }}
            onClick={() => setStep('chooser')}
          >
            Back
          </button>
        </>
      )}

      {step === 'studentOtp' && pendingStudent && (
        <>
          <div className="wordmark">[App name]</div>
          <div className="stepper">
            <div className="seg done" />
            <div className="seg current" />
            <div className="seg" />
          </div>
          <h1 className="title">Enter your code</h1>
          <p className="sub-text">We sent a code to {pendingStudent.phone}.</p>
          <div className="card">
            <label className="field-label">4-digit code</label>
            <div className="otp-row">
              {otp.map((digit, i) => (
                <input
                  key={i}
                  className="otp-box"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => {
                    const v = e.target.value.replace(/\D/g, '');
                    const next = [...otp];
                    next[i] = v;
                    setOtp(next);
                    if (v && i < 3) {
                      const nextInput = e.target.parentElement?.children[i + 1] as HTMLInputElement | undefined;
                      nextInput?.focus();
                    }
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Backspace' && !otp[i] && i > 0) {
                      const prevInput = e.currentTarget.parentElement?.children[i - 1] as HTMLInputElement | undefined;
                      prevInput?.focus();
                    }
                  }}
                />
              ))}
            </div>
            {otpErr && <p className="error-text">Enter all 4 digits.</p>}
            <button className="btn block" style={{ marginTop: 14 }} onClick={submitOtp}>
              Verify
            </button>
          </div>
          <button
            className="linkbtn" style={{ display: 'block', marginTop: 14, textAlign: 'center', width: '100%' }}
            onClick={() => setStep('studentPhone')}
          >
            Use a different number
          </button>
        </>
      )}
    </div>
  );
}
