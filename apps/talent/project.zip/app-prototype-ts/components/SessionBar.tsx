'use client';

import { useAppState } from '@/context/AppState';

export default function SessionBar({ whoLabel }: { whoLabel: string }) {
  const { logout } = useAppState();
  return (
    <div className="sessionbar">
      <span>
        Signed in as <span className="who">{whoLabel}</span>
      </span>
      <span className="sessionbar-actions">
        <button className="linkbtn" onClick={logout}>Log out</button>
      </span>
    </div>
  );
}
