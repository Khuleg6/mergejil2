# [App name] — frontend prototype (TypeScript / Next.js)

Runnable port of the HTML prototype your teammate liked. Same screens, same
interactions, same look — now real React components instead of hand-written DOM
manipulation, so it drops into an actual Next.js codebase.

## Run it

```bash
npm install
npm run dev
```

Open http://localhost:3000 — sign in as either role from the same screen (there's a
"fill in a demo student's number" shortcut on the student login step).

## What's here

- `app/` — the three routes: `/` (login), and role-based views rendered from the same
  page based on session state
- `components/` — `AuthGate`, `TeacherShell` (5 tabs: Classes, Materials, Assignment,
  Grading, Reports), `StudentShell` (Today, Word cycle, Practice, Avatars)
- `context/AppState.tsx` — holds all data in React state; teacher actions (unlocking a
  phase, grading) immediately show up on the student side and back
- `lib/` — the actual logic (streak math, phase-locking rules, avatar unlocks). This is
  the same code that was type-checked and unit-tested earlier, just reused here instead
  of rewritten.

## What's deliberately not here yet

**No backend, no GraphQL.** Everything lives in React state and resets on refresh.
That's on purpose — GraphQL/D1 wiring was explicitly deferred for later. When that's
ready, only `context/AppState.tsx` needs to change (swap the in-memory calls for API
calls); no component should need to change, since they only ever talk to `useAppState()`.

Verified: `npm run build` compiles clean, and the dev server was started and hit with a
real request to confirm it actually serves the page — not just that it type-checks.
